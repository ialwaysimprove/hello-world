<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "junior";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully <br>";

$stmt = $conn->prepare("INSERT INTO ratings_bajjar (user_id, time, rating) VALUES (?, current_timestamp(), ?) ");
$sql = $stmt->bind_param("sd", $user_id, $rating);
$user_id = $_POST['user_id'];
//$date = $_POST['date'];
$rating = $_POST['rating'];
echo "\n User_ID" . $user_id . "\n Rating:  " . $rating ."<br>";
if ($stmt->execute()) {
    echo "New record created successfully<br>";
    
} else {
    echo "Error: " . $sql . "<br>" . $conn->error ."<br>";
}
$stmt->close();
$conn->close();

?>
